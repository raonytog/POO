package q1;

/**
 * Questão 1.
 * 
 * Crie classes para representar dados sobre um campeonato de futebol, com suas
 * partidas e seus lances (faltas ou gols). 
 * 
 * Implemente funcionalidades nas suas classes para identificar a partida com o maior número de gols
 * em um campeonato, e para identificar as partidas de um campeonato em que houve gols contra.
 * 
 * Siga o diagrama UML fornecido. (O diagrama mostra alguns atributos, mas não é 
 * exaustivo quanto aos atributos e operações. Adicione aqueles que foram necessários.)
 * 
 * Atenção às indicações de navegabilidade e às cardinalidades. Veja que "Lance" é uma
 * classe abstrata (e não é uma interface).
 * 
 * Crie um testador no método main desta classe TestadorQ1 instanciando um campeonato, 
 * algumas partidas e lances, e invoque as funcionalidade exigidas acima. 
 *
 * Escreva o seu nome em cada arquivo que produzir ou alterar.
 * 
 */

public class TestadorQ1 {

	public static void main(String[] args) {

	}

}
